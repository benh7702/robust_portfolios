# From Factor Zoo to Alpha - Research Report

This is the standalone, hand-authored paper accompanying the separate Python research repository. It uses Ben Heskin's supplied NYU question-and-solution LaTeX template as its base. No Python command writes, rewrites, or formats this report.

## Contents

- `research_report.tex` - editable LaTeX source
- `research_report.pdf` - compiled paper
- `figures/` - frozen copies of the six figures used in the paper

## Compile

Install [Tectonic](https://tectonic-typesetting.github.io/) and run:

```bash
tectonic research_report.tex
```

The report is self-contained: all image paths resolve inside this directory. Numerical results were frozen from the reproducible demonstration run described in the paper.
